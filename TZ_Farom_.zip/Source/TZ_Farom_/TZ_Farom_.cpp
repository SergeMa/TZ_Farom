// Copyright Epic Games, Inc. All Rights Reserved.

#include "TZ_Farom_.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, TZ_Farom_, "TZ_Farom_" );
